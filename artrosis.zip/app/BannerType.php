<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BannerType extends Model
{
    protected $fillable = ['name'];
}
