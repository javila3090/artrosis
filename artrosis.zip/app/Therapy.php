<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Therapy extends Model
{
    //
}
